# CSS  ![CSS](https://img.shields.io/badge/CSS-239120?&style=for-the-badge&logo=css3&logoColor=white)


 En esta carpeta se alojaran todos los documentos relacionados con el estilo de la aplicacion, lo cual incluye fuentes de texto, colores, tamaños, diseños, etc. 

## Estructura de Archivos
>IntegradoraI-New Vision<br>
>| - Backend<br>
>| - Database<br>
>| - Documentation
>**| - FrontEnd** <br>
>&nbsp;&nbsp;|- Assets<br>
>&nbsp;&nbsp;**|- CSS**<br>
>&nbsp;&nbsp;|- HTML<br>
>&nbsp;&nbsp;|- JS<br>

## Equipo de Desarrollo

|Integrante|Contacto|Rol|Observaciones|
|------------|--------|---|---|
|Osvaldo Abishai Flores Campos|[@AbishaiFC](https://github.com/AbishaiFC)|Lider de Databases|✅Revisado y aprobado|
|Carlos Isaac Fosado Escudero|[@CarlosFosadoo](https://github.com/CarlosFosadoo)|Lider de Documentacion|😐 En revision.|
|Ailton Artiaga Quiroga|[@ArtQuir29](https://github.com/ArtQuir29)|Lider de Desarrollo de FrontEnd y BackEnd |😐En revision.|